from django.contrib import admin
from .models import Videojuego, Plataforma, Copia
# Register your models here.

admin.site.register(Videojuego)
admin.site.register(Plataforma)
admin.site.register(Copia)