"""
URL configuration for miproyecto project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    #vistas basadas en clases

    path('videojuegos/', views.VideojuegoListView.as_view(), name='videojuegos'),
    path('videojuego/<int:pk>', views.VideojuegoDetailView.as_view(), name="videojuego"),
    path('videojuego/crear/', views.VideojuegoCreateView.as_view(), name='videojuego-create'),
    path('videojuego/editar/<int:pk>/', views.VideojuegoUpdateView.as_view(), name='videojuego-update'),
    path('videojuego/eliminar/<int:pk>/', views.VideojuegoDeleteView.as_view(), name='videojuego-delete'),

    path('plataformas/', views.PlataformaListView.as_view(), name='plataformas'),
    path('plataforma/<int:pk>', views.PlataformaDetailView.as_view(), name="plataforma"),
    path('plataforma/crear/', views.PlataformaCreateView.as_view(), name='plataforma-create'),
    path('plataforma/editar/<int:pk>/', views.PlataformaUpdateView.as_view(), name='plataforma-update'),
    path('plataforma/eliminar/<int:pk>/', views.PlataformaDeleteView.as_view(), name='plataforma-delete'),

    path('alquiladas/', views.CopiaListView.as_view(), name="alquiladas"),

    path('busqueda/', views.busqueda, name="busqueda"),

]
